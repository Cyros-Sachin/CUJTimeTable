<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Db;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Cell\DataValidation;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

class ExcelService
{
    private static function styleHeaderRow($sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => ['bold' => true, 'color' => ['argb' => 'FFFFFFFF']],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['argb' => 'FF1E3A8A']],
            'alignment' => ['horizontal' => 'center', 'vertical' => 'center'],
            'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN]],
        ]);
    }

    private static function borderRange($sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN]],
        ]);
    }

    private static function sanitizeSheetName(string $name): string
    {
        $clean = preg_replace('/[\[\]:\*\?\/\\\\]/', '', $name);
        $clean = mb_substr($clean, 0, 31);
        return $clean === '' ? 'Sheet' : $clean;
    }

    /**
     * Entry upload template. Every choice column (Program, Semester, Subject Type,
     * Date, Time Slot) is a dropdown fed from live data: the programs of the given
     * department, the semesters those programs have, Core/Elective, the exam cycle's
     * date window and the active time slots. Dates are plain DD-MM-YYYY text so the
     * dropdown value is never re-interpreted by Excel's locale.
     */
    public static function buildTemplateWorkbook(string $examType, ?int $cycleId = null, ?int $departmentId = null, ?int $programId = null): Spreadsheet
    {
        $pdo = Db::conn();

        $sql = 'SELECT name, total_semesters FROM programs WHERE is_active = 1';
        $args = [];
        if ($departmentId) {
            $sql .= ' AND department_id = :d';
            $args['d'] = $departmentId;
        }
        if ($programId) {
            $sql .= ' AND id = :p';
            $args['p'] = $programId;
        }
        $stmt = $pdo->prepare($sql . ' ORDER BY name');
        $stmt->execute($args);
        $programs = $stmt->fetchAll();
        // A single program (chosen, or the department only has one) is pre-filled and locked.
        $locked = count($programs) === 1;
        if ($departmentId) {
            $stmt = $pdo->prepare('SELECT name FROM departments WHERE id = :d');
            $stmt->execute(['d' => $departmentId]);
            $deptName = $stmt->fetch()['name'] ?? null;
        } else {
            $deptName = null;
        }
        $timeSlots = $pdo->query('SELECT label FROM time_slots WHERE is_active = 1 ORDER BY start_time')->fetchAll();
        $subjectTypes = $pdo->query('SELECT name FROM subject_types WHERE is_active = 1 ORDER BY id')->fetchAll();

        $cycle = null;
        $dates = [];
        if ($cycleId) {
            $stmt = $pdo->prepare('SELECT title, month_year, start_date, end_date FROM exam_cycles WHERE id = :id');
            $stmt->execute(['id' => $cycleId]);
            $cycle = $stmt->fetch() ?: null;
        }
        if ($cycle) {
            $cursor = new \DateTimeImmutable($cycle['start_date']);
            $end = new \DateTimeImmutable($cycle['end_date']);
            while ($cursor <= $end && count($dates) < 400) {
                $dates[] = $cursor->format('d-m-Y');
                $cursor = $cursor->modify('+1 day');
            }
        }
        $maxSemester = max(1, ...array_map(fn ($p) => (int) $p['total_semesters'], $programs ?: [['total_semesters' => 1]]));

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Entries');
        $listsSheet = $spreadsheet->createSheet();
        $listsSheet->setTitle('Lists');
        $listsSheet->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
        $guide = $spreadsheet->createSheet();
        $guide->setTitle('Instructions');

        foreach ($programs as $i => $p) {
            $listsSheet->setCellValue('A' . ($i + 1), $p['name']);
            $listsSheet->setCellValue('F' . ($i + 1), (int) $p['total_semesters']);
        }
        foreach ($subjectTypes as $i => $s) {
            $listsSheet->setCellValue('B' . ($i + 1), $s['name']);
        }
        foreach ($timeSlots as $i => $t) {
            $listsSheet->setCellValue('C' . ($i + 1), $t['label']);
        }
        foreach ($dates as $i => $d) {
            $listsSheet->setCellValueExplicit('D' . ($i + 1), $d, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
        }
        for ($n = 1; $n <= $maxSemester; $n++) {
            $listsSheet->setCellValue('E' . $n, $n);
        }

        $headers = ['Program', 'Semester', 'Subject Type', 'Date', 'Time Slot', 'Course Code', 'Course Name', 'No. of Students'];
        foreach ($headers as $i => $h) {
            $sheet->setCellValue([$i + 1, 1], $h);
            $sheet->getColumnDimensionByColumn($i + 1)->setWidth($h === 'Course Name' ? 36 : 22);
        }
        self::styleHeaderRow($sheet, 'A1:H1');
        $sheet->freezePane('A2');

        $lists = [
            'A' => ['col' => 'A', 'count' => count($programs), 'title' => 'Program'],
            'B' => ['col' => 'E', 'count' => $maxSemester, 'title' => 'Semester'],
            'C' => ['col' => 'B', 'count' => count($subjectTypes), 'title' => 'Subject Type'],
            'D' => ['col' => 'D', 'count' => count($dates), 'title' => 'Date'],
            'E' => ['col' => 'C', 'count' => count($timeSlots), 'title' => 'Time Slot'],
        ];

        $sheet->getStyle('D2:D1001')->getNumberFormat()->setFormatCode('@');
        $programCount = max(count($programs), 1);
        for ($row = 2; $row <= 1001; $row++) {
            foreach ($lists as $sheetCol => $def) {
                if ($sheetCol === 'A' && $locked) {
                    $sheet->setCellValue("A{$row}", $programs[0]['name']);
                    continue;
                }
                $count = max($def['count'], 1);
                $dv = $sheet->getCell("{$sheetCol}{$row}")->getDataValidation();
                $dv->setType(DataValidation::TYPE_LIST);
                $dv->setErrorStyle(DataValidation::STYLE_STOP);
                $dv->setAllowBlank(true);
                $dv->setShowDropDown(false);
                $dv->setShowErrorMessage(true);
                $dv->setErrorTitle($def['title']);
                $dv->setError('Pick a value from the dropdown list.');
                if ($sheetCol === 'B' && !$locked) {
                    // Semester choices follow the program on the same row.
                    $dv->setError('Pick the Program first, then a semester from the dropdown.');
                    $dv->setFormula1("OFFSET(Lists!\$E\$1,0,0,INDEX(Lists!\$F\$1:\$F\${$programCount},MATCH(\$A{$row},Lists!\$A\$1:\$A\${$programCount},0)),1)");
                } elseif ($sheetCol === 'B') {
                    $dv->setFormula1('Lists!$E$1:$E$' . max((int) $programs[0]['total_semesters'], 1));
                } else {
                    $dv->setFormula1("Lists!\${$def['col']}\$1:\${$def['col']}\${$count}");
                }
            }
            $dv = $sheet->getCell("H{$row}")->getDataValidation();
            $dv->setType(DataValidation::TYPE_WHOLE);
            $dv->setOperator(DataValidation::OPERATOR_BETWEEN);
            $dv->setAllowBlank(true);
            $dv->setShowErrorMessage(true);
            $dv->setErrorTitle('No. of Students');
            $dv->setError('Enter a whole number between 1 and 5000.');
            $dv->setFormula1('1');
            $dv->setFormula2('5000');
        }
        self::borderRange($sheet, 'A1:H1');
        if ($locked) {
            // Only the Program column stays locked; every other cell is editable.
            $sheet->getStyle('B2:H1001')->getProtection()->setLocked(\PhpOffice\PhpSpreadsheet\Style\Protection::PROTECTION_UNPROTECTED);
            $sheet->getProtection()->setSheet(true);
            $sheet->getProtection()->setFormatColumns(false);
            $sheet->getProtection()->setFormatRows(false);
        }

        $guide->getColumnDimension('A')->setWidth(110);
        $cycleLine = $cycle
            ? "{$cycle['title']} - {$cycle['month_year']} ({$dates[0]} to " . end($dates) . ')'
            : 'not specified';
        $lines = [
            'Exam cycle: ' . $cycleLine,
            'Department: ' . ($deptName ?? 'all departments'),
            $locked ? "Program: {$programs[0]['name']} (pre-filled and locked - do not change)" : 'Program: pick from the dropdown (only programs you are allowed to upload for are listed)',
            'Exam type: ' . ($examType === 'REAPPEAR' ? 'Re-appear' : 'Regular'),
            '',
            'Fill one exam per row from row 2 downward.',
            'Program, Semester, Subject Type, Date and Time Slot are dropdowns - pick the value, do not type it.',
            'Semester choices depend on the Program of the same row. Only Course Code, Course Name and No. of Students are typed.',
            'Rows with a program from another department are rejected on upload.',
            'Date list contains only the dates of the selected exam cycle.',
            'Course Code: letters/digits, e.g. MBIO1C004T. Course Name: 2-200 characters.',
            'No. of Students: whole number 1-5000.',
            'Do not rename or reorder the header row. Max 1000 rows. Upload the file under the same exam type and cycle.',
            'Download a fresh template if programs, time slots or the cycle dates change.',
        ];
        foreach ($lines as $i => $line) {
            $guide->setCellValue('A' . ($i + 1), $line);
        }
        $guide->getStyle('A1')->getFont()->setBold(true);

        $spreadsheet->setActiveSheetIndex(0);
        return $spreadsheet;
    }

    /**
     * @param array $rows each with weekday/exam_date/... fields (see EntryService::ENTRY_SELECT)
     * @param array $dayWise each with exam_date, weekday, time_slot_label, paper_count, total_students, departments[]
     * @param array<string,array> $byDepartment department name => rows
     */
    public static function buildConsolidatedWorkbook(array $rows, array $dayWise, array $byDepartment): Spreadsheet
    {
        $spreadsheet = new Spreadsheet();
        $consolidated = $spreadsheet->getActiveSheet();
        $consolidated->setTitle('Consolidated');

        $headers = ['S.No', 'Date', 'Day', 'Time', 'Department', 'Program', 'Semester', 'Exam Type', 'Subject Type', 'Course Code', 'Course Name', 'No. of Students'];
        foreach ($headers as $i => $h) {
            $consolidated->setCellValue([$i + 1, 1], $h);
            $consolidated->getColumnDimensionByColumn($i + 1)->setWidth($h === 'Course Name' ? 30 : 16);
        }
        $lastCol = chr(ord('A') + count($headers) - 1);
        self::styleHeaderRow($consolidated, "A1:{$lastCol}1");
        $consolidated->setAutoFilter("A1:{$lastCol}1");
        $consolidated->freezePane('A2');

        $r = 2;
        foreach ($rows as $i => $row) {
            $consolidated->setCellValue("A{$r}", $i + 1);
            $consolidated->setCellValue("B{$r}", ExcelDate::stringToExcel($row['exam_date']));
            $consolidated->getStyle("B{$r}")->getNumberFormat()->setFormatCode('dd-mm-yyyy');
            $consolidated->setCellValue("C{$r}", $row['weekday']);
            $consolidated->setCellValue("D{$r}", $row['time_slot_label']);
            $consolidated->setCellValue("E{$r}", $row['department_name']);
            $consolidated->setCellValue("F{$r}", $row['program_name']);
            $consolidated->setCellValue("G{$r}", $row['semester']);
            $consolidated->setCellValue("H{$r}", $row['exam_type'] === 'REGULAR' ? 'Regular' : 'Re-appear');
            $consolidated->setCellValue("I{$r}", $row['subject_type_name']);
            $consolidated->setCellValue("J{$r}", $row['course_code']);
            $consolidated->setCellValue("K{$r}", $row['course_name']);
            $consolidated->setCellValue("L{$r}", $row['student_count']);
            $r++;
        }
        if ($r > 2) {
            self::borderRange($consolidated, "A1:{$lastCol}" . ($r - 1));
        }

        $dayWiseSheet = $spreadsheet->createSheet();
        $dayWiseSheet->setTitle('Day-wise Summary');
        $dwHeaders = ['Date', 'Day', 'Time', 'No. of Papers', 'Total Students', 'Departments Involved'];
        foreach ($dwHeaders as $i => $h) {
            $dayWiseSheet->setCellValue([$i + 1, 1], $h);
            $dayWiseSheet->getColumnDimensionByColumn($i + 1)->setWidth($h === 'Departments Involved' ? 36 : 18);
        }
        self::styleHeaderRow($dayWiseSheet, 'A1:F1');
        $r = 2;
        foreach ($dayWise as $d) {
            $dayWiseSheet->setCellValue("A{$r}", ExcelDate::stringToExcel($d['exam_date']));
            $dayWiseSheet->getStyle("A{$r}")->getNumberFormat()->setFormatCode('dd-mm-yyyy');
            $dayWiseSheet->setCellValue("B{$r}", $d['weekday']);
            $dayWiseSheet->setCellValue("C{$r}", $d['time_slot_label']);
            $dayWiseSheet->setCellValue("D{$r}", $d['paper_count']);
            $dayWiseSheet->setCellValue("E{$r}", $d['total_students']);
            $dayWiseSheet->setCellValue("F{$r}", implode(', ', $d['departments']));
            $r++;
        }
        if ($r > 2) {
            self::borderRange($dayWiseSheet, 'A1:F' . ($r - 1));
        }

        foreach ($byDepartment as $deptName => $deptRows) {
            $sheet = $spreadsheet->createSheet();
            $sheet->setTitle(self::sanitizeSheetName($deptName));
            $deptHeaders = array_slice($headers, 1);
            foreach ($deptHeaders as $i => $h) {
                $sheet->setCellValue([$i + 1, 1], $h);
                $sheet->getColumnDimensionByColumn($i + 1)->setWidth($h === 'Course Name' ? 30 : 16);
            }
            $lastDeptCol = chr(ord('A') + count($deptHeaders) - 1);
            self::styleHeaderRow($sheet, "A1:{$lastDeptCol}1");

            $r = 2;
            foreach ($deptRows as $row) {
                $sheet->setCellValue("A{$r}", ExcelDate::stringToExcel($row['exam_date']));
                $sheet->getStyle("A{$r}")->getNumberFormat()->setFormatCode('dd-mm-yyyy');
                $sheet->setCellValue("B{$r}", $row['weekday']);
                $sheet->setCellValue("C{$r}", $row['time_slot_label']);
                $sheet->setCellValue("D{$r}", $row['department_name']);
                $sheet->setCellValue("E{$r}", $row['program_name']);
                $sheet->setCellValue("F{$r}", $row['semester']);
                $sheet->setCellValue("G{$r}", $row['exam_type'] === 'REGULAR' ? 'Regular' : 'Re-appear');
                $sheet->setCellValue("H{$r}", $row['subject_type_name']);
                $sheet->setCellValue("I{$r}", $row['course_code']);
                $sheet->setCellValue("J{$r}", $row['course_name']);
                $sheet->setCellValue("K{$r}", $row['student_count']);
                $r++;
            }
            if ($r > 2) {
                self::borderRange($sheet, "A1:{$lastDeptCol}" . ($r - 1));
            }
        }

        $spreadsheet->setActiveSheetIndex(0);
        return $spreadsheet;
    }
}
